package hw2;

import edu.princeton.cs.algs4.WeightedQuickUnionUF;

public class Percolation {
    private final WeightedQuickUnionUF WQU;
    private WeightedQuickUnionUF quickUnion2;
    private boolean[][] grid;
    private int length;
    private int virTop;
    private int virBottom;
    private int sitesOpen;

    // create a helper method that returns the element number given a row and col
    private static int getNum(int length, int row, int col) {
        return length * row + col;
    }

    // create N-by-N grid, with all sites initially blocked
    public Percolation(int N) {
        length = N;
        virTop = N * N;
        virBottom = N * N + 1;
        sitesOpen = 0;
        WQU = new WeightedQuickUnionUF(N * N + 2);
        quickUnion2 = new WeightedQuickUnionUF(N * N + 1);
        if (N <= 0) {
            throw new java.lang.IllegalArgumentException();
        } else {
            grid = new boolean[N][N];
        }
    }

    // open the site (row, col) if it is not open already
    public void open(int row, int col) {
        if (row < 0 || col < 0 || row > length || col > length) {
            throw new java.lang.IndexOutOfBoundsException();
        } else {
            if (!grid[row][col]) {
                sitesOpen += 1;
                grid[row][col] = true;
            }
            int curr = getNum(length, row, col);
            // check if site above is open
            if (row > 0 && isOpen(row - 1, col)) {
                int above = getNum(length, row - 1, col);
                WQU.union(curr, above);
                quickUnion2.union(curr, above);
                // check if site below is open
            }
            if (row < length - 1 && isOpen(row + 1, col)) {
                int below = getNum(length, row + 1, col);
                WQU.union(curr, below);
                quickUnion2.union(curr, below);
                // check if site left is open
            }
            if (col > 0 && isOpen(row, col - 1)) {
                int left = getNum(length, row, col - 1);
                WQU.union(curr, left);
                quickUnion2.union(curr, left);
                // check if site right is open
            }
            if (col < length - 1 && isOpen(row, col + 1)) {
                int right = getNum(length, row, col + 1);
                WQU.union(curr, right);
                quickUnion2.union(curr, right);
                // check if open site is at the top or bottom of grid
            }
            if (row == 0) {
                WQU.union(curr, virTop);
                quickUnion2.union(curr, virTop);
            }
            if (row == length - 1) {
                WQU.union(curr, virBottom);
            }
        }
    }

    // is the site (row, col) open?
    public boolean isOpen(int row, int col) {
        if (row < 0 || row > length - 1 || col < 0 || col > length - 1) {
            throw new java.lang.IndexOutOfBoundsException();
        } else {
            return grid[row][col];
        }
    }

    // is the site (row, col) full?
    public boolean isFull(int row, int col) {
        if (row < 0 || row > length - 1 || col < 0 || col > length - 1) {
            throw new java.lang.IndexOutOfBoundsException();
        } else {
            int curr = getNum(length, row, col);
            return quickUnion2.connected(curr, virTop);
        }
    }

    // number of open sites
    public int numberOfOpenSites() {
        return sitesOpen;
    }

    // does the system percolate?
    public boolean percolates() {
        return WQU.connected(virTop, virBottom);
    }
}
