package hw2;

import edu.princeton.cs.algs4.StdRandom;
import edu.princeton.cs.algs4.StdStats;

public class PercolationStats {
    private int trials;
    private Percolation testPerc;
    private double[] percThresh;

    // perform T independent experiments on an N-by-N grid
    public PercolationStats(int N, int T, PercolationFactory pf) {
        if (N <= 0 || T <= 0) {
            throw new java.lang.IllegalArgumentException();
        } else {
            trials = T;
            percThresh = new double[T];
            for (int i = 0; i < T; i += 1) {
                testPerc = pf.make(N);
                int sitesOpen = 0;
                while (!testPerc.percolates()) {
                    int row = StdRandom.uniform(0, N);
                    int col = StdRandom.uniform(0, N);
                    if (!testPerc.isOpen(row, col)) {
                        testPerc.open(row, col);
                        sitesOpen += 1;
                    }
                }
                double sitesOpen2 = sitesOpen;
                double thresh = sitesOpen2 / (N * N);
                percThresh[i] = thresh;
            }
        }
    }
    // sample mean of percolation threshold
    public double mean() {
        return StdStats.mean(percThresh);
    }
    // sample standard deviation of percolation threshold
    public double stddev() {
        return StdStats.stddev(percThresh);
    }
    // low endpoint of 95% confidence interval
    public double confidenceLow() {
        double num = 1.96 * stddev();
        double den = Math.sqrt(trials);
        return mean() - (num / den);
    }
    // high endpoint of 95% confidence interval
    public double confidenceHigh() {
        double num = 1.96 * stddev();
        double den = Math.sqrt(trials);
        return mean() + (num / den);
    }
}