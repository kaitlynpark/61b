package hw2;

import org.junit.Test;

import static org.junit.Assert.*;

public class PercolationTests {

    @Test
    public void createGrid() {
        Percolation newGrid = new Percolation(3);
    }

    @Test
    public void randomPer() {
        Percolation newGrid = new Percolation(3);
        newGrid.open(1, 1);
        newGrid.open(0, 1);
    }
}

