package PlusWorld;
import org.junit.Test;
import static org.junit.Assert.*;

import byowTools.TileEngine.TERenderer;
import byowTools.TileEngine.TETile;
import byowTools.TileEngine.Tileset;

import java.util.Random;

/** Neil Kulkarni's HexWorld Live Code Demo https://www.youtube.com/watch?v=gkZIWy3QzTA */

/**
 * Draws a world consisting of plus shaped regions.
 */
public class PlusWorld {
    private static final int WIDTH = 50;
    private static final int HEIGHT = 50;

    public static void drawRow(TETile[][] tiles, Position p, TETile tile, int length) {
        for (int dx = 0; dx < length; dx++) {
            tiles[p.x + dx][p.y] = tile;
        }
    }

    // Helper method for addPlus
    public static void addPlusHelper(TETile[][] tiles, Position p, TETile tile, int t) {
        // Draw this row
        for (int i = 0; i < t; i++) {
            drawRow(tiles, p, tile, t);
            p = p.shift(0, -1);
        }

        Position startOfMiddleRow = p.shift(-t, 0);
        for (int i = 0; i < t; i++) {
            drawRow(tiles, startOfMiddleRow, tile, t * 3);
            startOfMiddleRow = startOfMiddleRow.shift(0, -1);
        }

        Position startOfLastRow = startOfMiddleRow.shift(t, 0);
        for (int i = 0; i < t; i++) {
            drawRow(tiles, startOfLastRow, tile, t);
            startOfLastRow = startOfLastRow.shift(0, -1);
        }
    }

    // Adds a plus to the world at position P of size s
    public static void addPlus(TETile[][] tiles, Position p, TETile t, int s) {
        if (s < 1) return;

        addPlusHelper(tiles, p, t, s);
    }

    // Fills the given 2D array of tiles with blank tiles
    public static void fillBoardWithNothing(TETile[][] tiles) {
        int height = tiles[0].length;
        int width = tiles.length;
        for (int x = 0; x < width; x++) {
            for (int y = 0; y < height; y++) {
                tiles[x][y] = Tileset.NOTHING;
            }
        }
    }

    // Private helper class to deal with positions

    private static class Position {
        int x;
        int y;

        Position(int x, int y) {
            this.x = x;
            this.y = y;
        }

        public Position shift(int dx, int dy) {
            return new Position(this.x + dx, this.y + dy);
        }
    }

    public static void addPlus(int s) {

    }

    // Draws the plus world
    public static void drawWorld(TETile[][] tiles) {
        fillBoardWithNothing(tiles);
        Position p = new Position(20, 20);
        addPlus(tiles, p, Tileset.FLOWER, 7);
    }
    public static void main(String[] args) {
        TERenderer ter = new TERenderer();
        ter.initialize(WIDTH, HEIGHT);

        TETile[][] world = new TETile[WIDTH][HEIGHT];
        drawWorld(world);

        ter.renderFrame(world);
    }
}
