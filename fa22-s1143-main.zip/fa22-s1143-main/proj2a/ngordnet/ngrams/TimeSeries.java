package ngordnet.ngrams;

import java.util.*;

/**
 * An object for mapping a year number (e.g. 1996) to numerical data. Provides
 * utility methods useful for data analysis.
 *
 * @author Josh Hug
 */
public class TimeSeries extends TreeMap<Integer, Double> {
    /**
     * Constructs a new empty TimeSeries.
     */
    public TimeSeries() {
        super();
    }

    /**
     * Creates a copy of TS, but only between STARTYEAR and ENDYEAR,
     * inclusive of both end points.
     */
    public TimeSeries(TimeSeries ts, int startYear, int endYear) {
        super();
        for (int key = startYear; key <= endYear; key++) {
            if (ts.containsKey(key)) {
                this.put(key, ts.get(key));
            } else {
                continue;
            }
        }
    }

    /**
     * Returns all years for this TimeSeries (in any order).
     */
    public List<Integer> years() {
        List<Integer> yearList = new ArrayList<>();
        Collection<Integer> keys = this.keySet();
        for (Integer key : keys) {
            yearList.add(key);
        }
        return yearList;
    }

    /**
     * Returns all data for this TimeSeries (in any order).
     * Must be in the same order as years().
     */
    public List<Double> data() {
        List<Double> dataList = new ArrayList<>();
        Collection<Double> values = this.values();
        for (Double value : values) {
            dataList.add(value);
        }
        return dataList;
    }

    /**
     * Returns the yearwise sum of this TimeSeries with the given TS. In other words, for
     * each year, sum the data from this TimeSeries with the data from TS. Should return a
     * new TimeSeries (does not modify this TimeSeries).
     */
    public TimeSeries plus(TimeSeries ts) {
        TimeSeries tsPlus = (TimeSeries) ts.clone();
        Set<Integer> keys = this.keySet();
        for (Integer key : keys) {
            if (ts.containsKey(key) && this.containsKey(key)) {
                tsPlus.put(key, tsPlus.get(key) + this.get(key));
            } else if (ts.containsKey(key)) {
                tsPlus.put(key, tsPlus.get(key));
            } else if (this.containsKey(key)) {
                tsPlus.put(key, this.get(key));
            }
        }
        return tsPlus;
    }

    /**
     * Returns the quotient of the value for each year this TimeSeries divided by the
     * value for the same year in TS. If TS is missing a year that exists in this TimeSeries,
     * throw an IllegalArgumentException. If TS has a year that is not in this TimeSeries, ignore it.
     * Should return a new TimeSeries (does not modify this TimeSeries).
     */
    public TimeSeries dividedBy(TimeSeries ts) {
        TimeSeries tsDividedBy = (TimeSeries) this.clone();
        Set<Integer> keys = this.keySet();
        for (Integer key : keys) {
            if (ts.containsKey(key) && this.containsKey(key)) {
                tsDividedBy.put(key, this.get(key) / ts.get(key));
            } else if (ts.containsKey(key) && !this.containsKey(key)) {
                continue;
            } else if (!ts.containsKey(key) && this.containsKey(key)) {
                throw new IllegalArgumentException();
            }
        }
        return tsDividedBy;
    }
}
