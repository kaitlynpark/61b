package ngordnet.ngrams;

import edu.princeton.cs.algs4.In;

import java.util.*;

/**
 * An object that provides utility methods for making queries on the
 * Google NGrams dataset (or a subset thereof).
 * <p>
 * An NGramMap stores pertinent data from a "words file" and a "counts
 * file". It is not a map in the strict sense, but it does provide additional
 * functionality.
 *
 * @author Josh Hug
 */

public class NGramMap {
    /**
     * Constructs an NGramMap from WORDSFILENAME and COUNTSFILENAME.
     */
    private HashMap<String, TimeSeries> wordsHashmap = new HashMap<String, TimeSeries>();
    private TimeSeries counts = new TimeSeries();
    private static final int START_YEAR = 1400;
    private static final int END_YEAR = 2100;

    public NGramMap(String wordsFilename, String countsFilename) {
        In wordsReader = new In(wordsFilename);
        while (!wordsReader.isEmpty()) {
            String word = wordsReader.readString();
            int wordYear = wordsReader.readInt();
            double wordAppearances = wordsReader.readDouble();
            wordsReader.readInt();

            TimeSeries tsTemp = new TimeSeries();

            if (wordsHashmap.containsKey(word)) {
                tsTemp = wordsHashmap.get(word);
            }
            tsTemp.put(wordYear, wordAppearances);
            wordsHashmap.put(word, tsTemp);
        }

        In countsReader = new In(countsFilename);
        while (!countsReader.isEmpty()) {
            String line = countsReader.readLine();
            String[] lineArray = line.split(",");
            int countYear = Integer.parseInt(lineArray[0]);
            double countTotal = Double.parseDouble(lineArray[1]);
            counts.put(countYear, countTotal);
        }

        /**
         String[] countsArray;
         countsArray = countsFilename.split(",");
         int i = 0;
         while (i < countsArray.length) {
         int countYear = Integer.parseInt(countsArray[i]);
         double countTotal = Double.parseDouble(countsArray[i + 1]);
         counts.put(countYear, countTotal);
         i = i + 4;
         }
         */
    }

    /**
     * Provides the history of WORD. The returned TimeSeries should be a copy,
     * not a link to this NGramMap's TimeSeries. In other words, changes made
     * to the object returned by this function should not also affect the
     * NGramMap. This is also known as a "defensive copy".
     */
    public TimeSeries countHistory(String word) {
        return (TimeSeries) wordsHashmap.get(word).clone();
    }

    /**
     * Provides the history of WORD between STARTYEAR and ENDYEAR, inclusive of both ends. The
     * returned TimeSeries should be a copy, not a link to this NGramMap's TimeSeries. In other words,
     * changes made to the object returned by this function should not also affect the
     * NGramMap. This is also known as a "defensive copy".
     */
    public TimeSeries countHistory(String word, int startYear, int endYear) {
        return new TimeSeries(countHistory(word), startYear, endYear);
    }

    /**
     * Returns a defensive copy of the total number of words recorded per year in all volumes.
     */
    public TimeSeries totalCountHistory() {
        return (TimeSeries) counts.clone();
    }

    /**
     * Provides a TimeSeries containing the relative frequency per year of WORD compared to
     * all words recorded in that year.
     */
    public TimeSeries weightHistory(String word) {
        return weightHistory(word, START_YEAR, END_YEAR);
    }

    /**
     * Provides a TimeSeries containing the relative frequency per year of WORD between STARTYEAR
     * and ENDYEAR, inclusive of both ends.
     */
    public TimeSeries weightHistory(String word, int startYear, int endYear) {
        return new TimeSeries(wordsHashmap.get(word).dividedBy(counts), startYear, endYear);
    }

    /**
     * Returns the summed relative frequency per year of all words in WORDS.
     */
    public TimeSeries summedWeightHistory(Collection<String> words) {
        return summedWeightHistory(words, START_YEAR, END_YEAR);
    }

    /**
     * Provides the summed relative frequency per year of all words in WORDS
     * between STARTYEAR and ENDYEAR, inclusive of both ends. If a word does not exist in
     * this time frame, ignore it rather than throwing an exception.
     */
    public TimeSeries summedWeightHistory(Collection<String> words, int startYear, int endYear) {
        TimeSeries tsReturn = new TimeSeries();
        for (String word : words) {
            tsReturn = tsReturn.plus(weightHistory(word, startYear, endYear));
        }
        return tsReturn;
    }
}
