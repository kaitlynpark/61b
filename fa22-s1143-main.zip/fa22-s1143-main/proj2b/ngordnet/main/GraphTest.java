package ngordnet.main;
import org.junit.Test;

import java.util.List;

import static org.junit.Assert.assertEquals;

public class GraphTest {
//    @Test
//    public void test1() {
//        Graph testGraph = new Graph();
//        testGraph.addEdge("event", "happening occurrence occurent natural_event");
//        testGraph.addEdge("event", "act human_action human_activity");
//        testGraph.addEdge("event", "transition");
//        System.out.println(testGraph.traverseGraph(0));
//    }
}

