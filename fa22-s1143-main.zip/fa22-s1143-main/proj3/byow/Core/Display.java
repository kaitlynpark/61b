package byow.Core;

import byow.TileEngine.TERenderer;
import byow.TileEngine.TETile;
import edu.princeton.cs.introcs.StdDraw;

import java.awt.*;
import java.util.Random;

import static byow.Core.World.drawWorld;

public class Display {
    /**
     * The width of the window of this game.
     */
    private int width;
    /**
     * The height of the window of this game.
     */
    private int height;
    /**
     * The Random object used to randomly generate Strings.
     */
    private Random rand;

    /**
     * The characters we generate random Strings from.
     */
    private static final char[] CHARACTERS = "abcdefghijklmnopqrstuvwxyz".toCharArray();

    public Display(int width, int height, long seed) {
        /* Sets up StdDraw so that it has a width by height grid of 16 by 16 squares as its canvas
         * Also sets up the scale so the top left is (0,0) and the bottom right is (width, height)
         */
        this.width = width;
        this.height = height;
        StdDraw.setCanvasSize(this.width * 16, this.height * 16);
        Font font = new Font("Monaco", Font.BOLD, 30);
        StdDraw.setFont(font);
        StdDraw.setXscale(0, this.width);
        StdDraw.setYscale(0, this.height);
        StdDraw.clear(Color.BLACK);
        titleScreen(); //Display Main menu
        StdDraw.enableDoubleBuffering();

        this.rand = new Random(seed);
    }

    //The Main Menu Screen
    public void titleScreen() {
        drawFrame("CS61B: THE GAME", 50);
        Font fontSmall = new Font("Monaco", Font.BOLD, 30);
        StdDraw.setFont(fontSmall);
        StdDraw.text(this.width / 2, this.height / 2 - 2, "New Game (N)");
        StdDraw.text(this.width / 2, this.height / 2 - 4, "Load Game (L)");
        StdDraw.text(this.width / 2, this.height / 2 - 6, "Quit (Q)");
    }


    private void drawFrame(String s, int size) {
        /* Take the input string S and display it at the center of the screen,
         * with the pen settings given below. */
        StdDraw.clear(Color.BLACK);
        StdDraw.setPenColor(Color.WHITE);
        Font font = new Font("Monaco", Font.BOLD, size);
        StdDraw.setFont(font);
        StdDraw.text(this.width / 2, this.height - this.height / 3, s);
        StdDraw.show();
    }

    public String solicitNCharsInput(int n) {
        //TODO: Read n letters of player input
        String s = "";
        while (s.length() != n) {
            if (StdDraw.hasNextKeyTyped()) {
                String nextKey = String.valueOf(StdDraw.nextKeyTyped());
                if (nextKey.equals("s") || nextKey.equals("S")) {
                    return s;
                } else {
                    s += nextKey;
                    drawFrame(s, 30);
                    StdDraw.text(this.width / 2, this.height / 2 + 2, "Enter Seed Number and Press 's' to Start: ");
                    StdDraw.show();
                }
            }
        }
        return s;
    }

    public void startGame() {
        String userInput = solicitNCharsInput(1);
        if (userInput.equals("N") || userInput.equals("n")) {
            //create new world;
//                StdDraw.clear(Color.BLACK);
//                StdDraw.text(this.width / 2, this.height / 2 + 2, "Enter Seed Number and Press 's' to Start: ");
//                StdDraw.show();
            String seed = solicitNCharsInput(20);
//            while (StdDraw.hasNextKeyTyped()) {
//                String digit = Character.toString(StdDraw.nextKeyTyped());
//                if (digit != "s" && digit != "S") {
//                    break;
//                }
//            }
            TERenderer ter = new TERenderer();
            ter.initialize(width, height);

            TETile[][] world = new TETile[width][height];
            drawWorld(world, 123);

            ter.renderFrame(world);
        }

        if (userInput.equals("L") || userInput.equals("l")) {
            //pull up the already saved status
        }
        if (userInput.equals("Q") || userInput.equals("q")) {
            //need to save current status
            System.exit(0);
        }
    }


    public static void main(String[] args) {
        if (args.length < 1) {
            System.out.println("Please enter a seed");
            return;
        }

        long seed = Long.parseLong(args[0]);
        Display game = new Display(80, 30, seed);
        game.startGame();
    }



    /*
    create a game state in engine or something .
    if it is equal to 0 we will display title screen.
    default game state will be title state

    ways to impliment "L" option
    seed currseed;
    currseed = whatever created
    press "l" -> world generated with currseed

     */
}


