package byow.Core;

import byow.Core.RandomUtils;
import byow.TileEngine.TERenderer;
import byow.TileEngine.TETile;
import byow.TileEngine.Tileset;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Random;
import java.util.concurrent.ThreadLocalRandom;

public class World {
    private long seed;
    private static ArrayList<Room> roomList = new ArrayList<>();
    private static ArrayList<Position> floor = new ArrayList<>();
    // Makes hashset of seeds and corresponding worlds
    private static HashMap<Integer, TETile[][]> seedsAndWorlds = new HashMap<>();

    private static class Room {
        int width;
        int height;
        Position topLeft;
        Position topRight;
        Position bottomLeft;
        Position bottomRight;
        boolean overlapping;
    }

    public static final int WIDTH = 80;
    public static final int HEIGHT = 30;

    // Add random n number of rooms to world
    public static void addNRooms(TETile[][] world) {
        Random rand = new Random();
        int n = ThreadLocalRandom.current().nextInt(15, 30);
        for (int i = 0; i < n; i++) {
            Position currPos = randomPos(WIDTH, HEIGHT);
            addRoom(world, currPos, Tileset.FLOOR);
        }
        drawHallways(world);
        drawWalls(world);
    }

    // Draw horizontal wall method
    public static void drawRow(TETile[][] world, Position pos, TETile tile, int width) {
        for (int dx = 0; dx < width; dx++) {
//            if (world[pos.x + dx][pos.y] == Tileset.NOTHING) {
            world[pos.x + dx][pos.y] = tile;
        }
    }

    // Draw vertical wall method
    public static void drawColumn(TETile[][] world, Position pos, TETile tile, int height) {
        for (int dy = 0; dy < height; dy++) {
            world[pos.x][pos.y + dy] = tile;
        }
    }

    // Add room helper method
    public static void addRoom(TETile[][] world, Position pos, TETile tile) {
        Room room = new Room();
        room.overlapping = false;
        room.width = ThreadLocalRandom.current().nextInt(3, 12);
        room.height = ThreadLocalRandom.current().nextInt(3, 12);
        if ((room.height < 3) || (room.width < 3) || (pos.x + room.width) >= WIDTH || (pos.y + room.height) >= HEIGHT) {
            return;
        }
        // Check for overlapping rooms
        for (int j = 0; j < room.height + 1; j++) {
            for (int i = 0; i < room.width + 1; i++) {
                if (world[pos.x + i][pos.y + j] == Tileset.FLOOR) {
                    room.overlapping = true;
                    break;
                }
            }
        }
        if (room.overlapping) {
            return;
        } else {
            // Reassign positions
            Position startFloor = pos;
            room.bottomLeft = startFloor;
            room.bottomRight = startFloor.shift(room.width, 0);
            room.topLeft = startFloor.shift(0, room.height);
            room.topRight = startFloor.shift(room.width, room.height);
            // Floor
            for (int k = 0; k < room.height; k++) {
                drawRow(world, startFloor, Tileset.FLOOR, room.width);
                startFloor = startFloor.shift(0, 1);
            }
            roomList.add(room);
//            Position original = pos;
//            // Bottom
//            drawRow(world, pos, tile, width + 1);
//            // Top
//            Position startTop = pos.shift(0, height);
//            drawRow(world, startTop, tile, width + 1);
//            // Left
//            drawColumn(world, original, tile, height);
//            // Right
//            Position startRight = original.shift(width, 0);
//            drawColumn(world, startRight, tile, height);
        }
    }

    // Add hallway helper method
    public static void drawHallways(TETile[][] world) {
        for (int i = 0; i < roomList.size() - 1; i++) {
            Room roomOne = roomList.get(i);
            Room roomTwo = roomList.get(i + 1);
            int roomOneX = RandomUtils.uniform(roomOne.bottomLeft.x, roomOne.bottomRight.x);
            int roomOneY = RandomUtils.uniform(roomOne.bottomLeft.y, roomOne.topRight.y);
            int roomTwoX = RandomUtils.uniform(roomTwo.bottomLeft.x, roomTwo.bottomRight.x);
            int roomTwoY = RandomUtils.uniform(roomTwo.bottomLeft.y, roomTwo.topRight.y);
            int xDiff = Math.abs(roomTwoX - roomOneX);
            int yDiff = Math.abs(roomTwoY - roomOneY);
            // roomOne sw of roomTwo
            if (roomOneX <= roomTwoX && roomOneY <= roomTwoY) {
                for (int j = 1; j <= xDiff; j++) {
                    world[roomOneX + j][roomOneY] = Tileset.FLOOR;
                    Position pos = new Position(roomOneX + j, roomOneY);
                    floor.add(pos);
                }
                for (int j = 1; j <= yDiff; j++) {
                    world[roomOneX + xDiff][roomOneY + j] = Tileset.FLOOR;
                    Position pos = new Position(roomOneX + xDiff, roomOneY + j);
                    floor.add(pos);
                }
            }
            // roomOne nw of roomTwo
            if (roomOneX <= roomTwoX && roomOneY >= roomTwoY) {
                for (int j = 1; j <= xDiff; j++) {
                    world[roomOneX + j][roomOneY] = Tileset.FLOOR;
                    Position pos = new Position(roomOneX + j, roomOneY);
                    floor.add(pos);
                }
                for (int j = 1; j <= yDiff; j++) {
                    world[roomOneX + xDiff][roomOneY - j] = Tileset.FLOOR;
                    Position pos = new Position(roomOneX + xDiff, roomOneY - j);
                    floor.add(pos);
                }
            }
            // roomOne se of roomTwo
            if (roomOneX >= roomTwoX && roomOneY <= roomTwoY) {
                for (int j = 1; j <= xDiff; j++) {
                    world[roomOneX - j][roomOneY] = Tileset.FLOOR;
                    Position pos = new Position(roomOneX - j, roomOneY);
                    floor.add(pos);
                }
                for (int j = 1; j <= yDiff; j++) {
                    world[roomOneX - xDiff][roomOneY + j] = Tileset.FLOOR;
                    Position pos = new Position(roomOneX - xDiff, roomOneY + j);
                    floor.add(pos);
                }
            }
            // roomOne ne of roomTwo
            if (roomOneX >= roomTwoX && roomOneY >= roomTwoY) {
                for (int j = 1; j <= xDiff; j++) {
                    world[roomOneX - j][roomOneY] = Tileset.FLOOR;
                    Position pos = new Position(roomOneX - j, roomOneY);
                    floor.add(pos);
                }
                for (int j = 1; j <= yDiff; j++) {
                    world[roomOneX - xDiff][roomOneY - j] = Tileset.FLOOR;
                    Position pos = new Position(roomOneX - xDiff, roomOneY - j);
                    floor.add(pos);
                }
            }
        }
    }

    // Add walls in every position bordering floor
    public static void drawWalls(TETile[][] world) {
        for (int j = 0; j < HEIGHT; j++) {
            for (int i = 0; i < WIDTH; i++) {
                if (world[i][j] == Tileset.NOTHING) {
                    continue;
                }
                    // Above pos
                if (world[i][j] == Tileset.FLOOR) {
                    if (world[i][j + 1] == Tileset.NOTHING) {
                        world[i][j + 1] = Tileset.WALL;
                    }
                    // Below pos
                    if (world[i][j - 1] == Tileset.NOTHING) {
                        world[i][j - 1] = Tileset.WALL;
                    }
                    // Left of pos
                    if (world[i - 1][j] == Tileset.NOTHING) {
                        world[i - 1][j] = Tileset.WALL;
                    }
                    // Right of pos
                    if (world[i + 1][j] == Tileset.NOTHING) {
                        world[i + 1][j] = Tileset.WALL;
                    }
                }
            }
        }
    }


    // Random position method
    public static Position randomPos(int width, int height) {
        int x = ThreadLocalRandom.current().nextInt(1, width);
        int y = ThreadLocalRandom.current().nextInt(1, height);
        return new Position(x, y);
    }

    // Private helper class to deal with positions
    private static class Position {
        int x;
        int y;

        Position(int x, int y) {
            this.x = x;
            this.y = y;
        }

        public Position shift(int dx, int dy) {
            return new Position(this.x + dx, this.y + dy);
        }
    }

    // Fills the given 2D array of tiles with blank tiles
    public static void fillBoardWithNothing(TETile[][] tiles) {
        int height = tiles[0].length;
        int width = tiles.length;
        for (int x = 0; x < width; x++) {
            for (int y = 0; y < height; y++) {
                tiles[x][y] = Tileset.NOTHING;
            }
        }
    }

    // Draws the world
    public static void drawWorld(TETile[][] world, int seed) {
        if (seedsAndWorlds.containsKey(seed)) {
            world = seedsAndWorlds.get(seed);
        } else {
            fillBoardWithNothing(world);
            Position p = new Position(2, 2);
            addNRooms(world);
        }
    }

    // Main method to test methods
    public static void main(String[] args) {
        TERenderer ter = new TERenderer();
        ter.initialize(WIDTH, HEIGHT);
        TETile[][] world = new TETile[WIDTH][HEIGHT];
        int seed = 123;
        drawWorld(world, seed);
        ter.renderFrame(world);
    }
}
